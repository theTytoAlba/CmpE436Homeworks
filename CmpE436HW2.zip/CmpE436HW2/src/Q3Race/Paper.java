package Q3Race;

public class Paper {
	String letterGrade;
	int numberGrade;
	int questionsAnswered;
	
	public Paper() {
		letterGrade = "";
		numberGrade = 0;
		questionsAnswered = 0;
	}
}
