Student name: Irmak Kavasoglu
Student ID: 2013400090
irmakkavasoglu@gmail.com

CmpE436 - Homework 2It has solutions to 3 homework questions.

- Solution of the first question is in the Q1 package.
  It expects 3 or 4 parameters. First two will be the dimensions, third will be the number of generations. Last argument is optional. It has the file name for the input. 
  Output is displayed on the screen, not written to a file.

- Solution of the second question is in the Q2 package.
  It demonstrates the dining philosophers problem for deadlock.

- Solution of the third question is in the Q3 package.
  It demonstrates a race condition.

This project is implemented in Eclipse. You can import the project.