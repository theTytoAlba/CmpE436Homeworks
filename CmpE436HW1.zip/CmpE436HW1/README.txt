Student name: Irmak Kavasoglu
Student ID: 2013400090
irmakkavasoglu@gmail.com

CmpE436 - Homework 1.

This project is implemented in Eclipse. You can import the project.

It has solutions to 2 homework questions.
- Solution of the first question is in the Question1.java class.
  This class expects 3 arguments. File name for the first matrix, file name for the second matrix, and the file name for the output.
  Input files must have the given structure that was described in the homework pdf.

- Solution of the second question is in the Question2.java and Question2Matrix.java classes.
  Question2.java is the runnable class, the other is the helper class.
  It expects 3 or 4 parameters. First two will be the dimensions, third will be the number of generations. Last argument is optional. It has the file name for the input. 
  Output is displayed on the screen, not written to a file.